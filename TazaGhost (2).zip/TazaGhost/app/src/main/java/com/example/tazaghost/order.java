package com.example.tazaghost;

import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class order extends AppCompatActivity {

    int resId;
    Integer Total = 0;
    Double Price = 0.00;

    TextView recievename, recieveprice, recieveprice1, noofItems;
    Button addtocart, Add, Sub;
    ImageView imagerecieve;

    FirebaseDatabase mDatabase;
    DatabaseReference mRef;
    private static final String TAG =  "MyTAG" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);


        addtocart = findViewById(R.id.AddtoCart);
        imagerecieve = (ImageView) findViewById(R.id.imagerecieve);

        recievename = (TextView) findViewById(R.id.etReciveName);
        recieveprice = (TextView) findViewById(R.id.etRecivePrice);
        recieveprice1 = (TextView) findViewById(R.id.etRecivePrice1);
        noofItems = (TextView) findViewById(R.id.quantity);

        Add = (Button) findViewById(R.id.btnAdd);
        Sub = (Button) findViewById(R.id.btnSub);

        mDatabase=FirebaseDatabase.getInstance();
        mRef=mDatabase.getReference(" Users");


        DisplayMetrics dm=new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);


        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)(width*.8),(int)(height*.8));

        WindowManager.LayoutParams params = getWindow().getAttributes();
        params.gravity = Gravity.CENTER;
        params.x=0;
        params.y=-20;

        getWindow().setAttributes(params);

        Intent intent2 = getIntent();
        String jalapenoo = intent2.getStringExtra("jalapenosend");
        String jalapenooprice = intent2.getStringExtra("jalapenopricesend");
        recievename.setText(jalapenoo);
        recieveprice.setText(jalapenooprice);
        recieveprice1.setText(jalapenooprice);


        Add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Total = Total + 1;
                noofItems.setText("" + Total);

                String p = recieveprice.getText().toString().trim();
                Double protein = Double.parseDouble(p);
                Price = Price += protein;
                recieveprice1.setText("" + Price);
            }
        });


        Sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Total >= 1) {
                    Total = Total - 1;

                    noofItems.setText("" + Total);

                    String p = recieveprice.getText().toString().trim();
                    Double protein = Double.parseDouble(p);

                    Price = Price -= protein;
                    recieveprice1.setText("" + Price);
                }
            }
        });
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            resId = bundle.getInt("resId");
            imagerecieve.setImageResource(resId);
        }



        addtocart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String oname = recievename.getText().toString();
                String oquantity = noofItems.getText().toString();
                String oprice = recieveprice1.getText().toString();
                String operprice = recieveprice.getText().toString();
                String key = mRef.push().getKey();

                mRef.child("Cart").child(key).child("ProductName").setValue(oname).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                        Toast.makeText(order.this,"Data Inserted Succesfully",Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Log.d(TAG,"OnFailure:" + e.getMessage());

                    }
                });

                mRef.child("Cart").child(key).child("PerProductPrice").setValue(operprice).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

//                        Toast.makeText(registration.this,"Data Inserted Succesfully",Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Log.d(TAG,"OnFailure:" + e.getMessage());

                    }
                });

                mRef.child("Cart").child(key).child("ProductQuantity").setValue(oquantity).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

//                        Toast.makeText(registration.this,"Data Inserted Succesfully",Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Log.d(TAG,"OnFailure:" + e.getMessage());

                    }
                });

                mRef.child("Cart").child(key).child("TotalProductPrice").setValue(oprice).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

//                        Toast.makeText(registration.this,"Data Inserted Succesfully",Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Log.d(TAG,"OnFailure:" + e.getMessage());

                    }
                });



//
//                String title=recievename.getText().toString().trim();
//                String quantity1=noofItems.getText().toString();
//                String price=recieveprice1.getText().toString();


//                Intent intent=new Intent(order.this,addtocart.class);
//                intent.putExtra("namesend",name1);
//                intent.putExtra("quantitysend",quantity1);
//                intent.putExtra("pricesend",price);
//                startActivity(intent);

//                String title=textTitle.getText().toString().trim();


//                Intent intent=new Intent(order.this,addtocart.class);
//                intent.putExtra("resId",resId);
//                intent.putExtra("title",title);
//                intent.putExtra("titlee",quantity1);
//                intent.putExtra("titleee",price);
//                startActivity(intent);


            }
        });

    }
}



