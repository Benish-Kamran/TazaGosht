package com.example.tazaghost;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;

public class login extends AppCompatActivity {

    EditText Lemail,Lpassword;
    Button signin,registerhere;

    FirebaseAuth mAuth;
    private static final String TAG =  "MyTAG" ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);


        Lemail=(EditText)findViewById(R.id.etLEmail);
        Lpassword=(EditText)findViewById(R.id.etLPassword);
        signin=(Button)findViewById(R.id.btnsignin);
        registerhere=(Button)findViewById(R.id.Registerhere);
        mAuth=FirebaseAuth.getInstance();

  signin.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {

           if (! ValidateEmailAddress() | ! validatePassword())
           {
               return;
           }

           String Email = Lemail.getText().toString().trim();
           String Password = Lpassword.getText().toString().trim();

           mAuth.signInWithEmailAndPassword(Email, Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
               @Override
               public void onComplete(@NonNull Task<AuthResult> task) {
                   if (task.isSuccessful()) {
                       Toast.makeText(login.this, "User Logged in", Toast.LENGTH_LONG).show();
                       Intent intent=new Intent(login.this,mainmenu.class);
                       startActivity(intent);
                       updateUI();
                   } else {

                       if (task.getException() instanceof FirebaseAuthInvalidCredentialsException)
                       {
                           Toast.makeText(login.this, "Invalid Password", Toast.LENGTH_LONG).show();
                           Lpassword.setText(" Invalid Password");
                       }
                       else if(task.getException() instanceof FirebaseAuthInvalidUserException)
                       {
                           Toast.makeText(login.this, "Email Not in Use", Toast.LENGTH_LONG).show();
                           Lemail.setText(" Email Not in Use");
                       }
                   }
               }
           });
       }


  });
        registerhere.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {

           Intent intent= new Intent(login.this,registration.class);
           startActivity(intent);
       }
   });

    }

    private void updateUI() {
        FirebaseUser user=mAuth.getCurrentUser();
        if (user==null)
        {
            Lemail.setText(" User not logged in");
            return;
        }
        else
        {
            Lemail.setText(user.getEmail());
        }
    }

    private boolean ValidateEmailAddress() {
        String Email=Lemail.getText().toString().trim();

        if (Email.isEmpty())
        {
            Lemail.setError("Email is Required.Cant be Empty");
            return false;
        }
        else if (!Patterns.EMAIL_ADDRESS.matcher(Email).matches())
        {
            Lemail.setError("Invalid Email. Enter valid Email address");
            return false;
        }
        else {
            Lemail.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String Password=Lpassword.getText().toString().trim();

        if (Password.isEmpty())
        {
            Lpassword.setError("Password is Required.Cant be Empty");
            return false;
        }
        else if (Password.length()<6)
        {
            Lpassword.setError("Password short Minimum 6 characters required");
            return false;
        }
        else {
            Lpassword.setError(null);
            return true;
        }
    }

}