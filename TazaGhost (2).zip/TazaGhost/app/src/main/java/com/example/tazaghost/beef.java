package com.example.tazaghost;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class beef extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_beef);



        final TextView boneless=(TextView)findViewById(R.id.boneless);
        final TextView bonelessprice=(TextView)findViewById(R.id.bonelessprice);
        Button bonelessorder=(Button) findViewById(R.id.btnOrderboneless);

        final TextView bonelesszerofat=(TextView)findViewById(R.id.bonelesszerofat);
        final TextView bonelesszerofatprice=(TextView)findViewById(R.id.bonelesszerofatPrice);
        Button bonelesszerofatorder=(Button) findViewById(R.id.btnOrderbonelesszerofat);

        final TextView boti=(TextView)findViewById(R.id.boti);
        final TextView botiprice=(TextView)findViewById(R.id.botiPrice);
        Button botiorder=(Button) findViewById(R.id.btnOrderboti);


        final TextView boung=(TextView)findViewById(R.id.boung);
        final TextView boungprice=(TextView)findViewById(R.id.boungprice);
        Button boungorder=(Button) findViewById(R.id.btnOrderboung);

        final TextView brain=(TextView)findViewById(R.id.brain);
        final TextView brainprice=(TextView)findViewById(R.id.brainPrice);
        Button brainorder=(Button) findViewById(R.id.btnOrderbrain);

        final TextView liver=(TextView)findViewById(R.id.liver);
        final TextView liverprice=(TextView)findViewById(R.id.liverPrice);
        Button liverorder=(Button) findViewById(R.id.btnOrderliver);

        final TextView mince=(TextView)findViewById(R.id.mince);
        final TextView minceprice=(TextView)findViewById(R.id.mincePrice);
        Button minceorder=(Button) findViewById(R.id.btnOrdermince);

        final TextView mincezerofat=(TextView)findViewById(R.id.mincezerofat);
        final TextView mincezerofatprice=(TextView)findViewById(R.id.mincezerofatPrice);
        Button mincezerofatorder=(Button) findViewById(R.id.btnOrdermincezerofat);

        final TextView nihari=(TextView)findViewById(R.id.nihari);
        final TextView nihariprice=(TextView)findViewById(R.id.nihariprice);
        Button nihariorder=(Button) findViewById(R.id.btnOrdernihari);

        final TextView pasandy=(TextView)findViewById(R.id.pasandy);
        final TextView pasandyprice=(TextView)findViewById(R.id.pasandyPrice);
        Button pasandyorder=(Button) findViewById(R.id.btnOrderpasandy);

        final TextView soup=(TextView)findViewById(R.id.soup);
        final TextView soupprice=(TextView)findViewById(R.id.soupPrice);
        Button souporder=(Button) findViewById(R.id.btnOrdersoup);

        final TextView undercut=(TextView)findViewById(R.id.under);
        final TextView undercutprice=(TextView)findViewById(R.id.underprice);
        Button undercutorder=(Button) findViewById(R.id.btnOrderunder);




        final TextView paya=(TextView)findViewById(R.id.buffalo);
        final TextView payaprice=(TextView)findViewById(R.id.buffaloprice);
        Button payaorder=(Button) findViewById(R.id.btnOrderbuffalo);



        bonelessorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=boneless.getText().toString();
                String jalapenooprice=bonelessprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bboneless);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });

        bonelesszerofatorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String jalapenoo=bonelesszerofat.getText().toString();
                String jalapenooprice=bonelesszerofatprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bbonelesszerofat);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        botiorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=boti.getText().toString();
                String jalapenooprice=botiprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bboti);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        boungorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=boung.getText().toString();
                String jalapenooprice=boungprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bboung);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        brainorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=brain.getText().toString();
                String jalapenooprice=brainprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bbrain);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        liverorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=liver.getText().toString();
                String jalapenooprice=liverprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bliver);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        minceorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=mince.getText().toString();
                String jalapenooprice=minceprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bmince);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        mincezerofatorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=mincezerofat.getText().toString();
                String jalapenooprice=mincezerofatprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bmincezerofat);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        nihariorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=nihari.getText().toString();
                String jalapenooprice=nihariprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bnihari);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        pasandyorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=pasandy.getText().toString();
                String jalapenooprice=pasandyprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bpasandy);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        souporder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=soup.getText().toString();
                String jalapenooprice=soupprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bsoup);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        undercutorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=undercut.getText().toString();
                String jalapenooprice=undercutprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.bundercut);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });






        payaorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=paya.getText().toString();
                String jalapenooprice=payaprice.getText().toString();

                Intent intent=new Intent(beef.this,order.class);
                intent.putExtra("resId",R.drawable.buffalo);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });
    }
}

