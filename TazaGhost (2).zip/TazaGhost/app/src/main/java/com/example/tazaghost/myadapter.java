package com.example.tazaghost;


import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.NumberFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class myadapter extends RecyclerView.Adapter<myadapter.ViewHolder> {

//    private LayoutInflater layoutInflater;
    Context context;
    private List<User> data;
    Integer Total = 0;
//    FirebaseDatabase mDatabase;
//            DatabaseReference mRef;
    private AdapterView.OnItemClickListener mListener;
//    Double Price2 = 0.00;a

//    myadapter(Context context, List<String> data){
//        this.layoutInflater = LayoutInflater.from(context);
//        this.data = data;
//    }

    public myadapter(Context context, List<User> data) {
        this.context = context;
        this.data = data;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.addtocart_sample,viewGroup,false);
        return new ViewHolder(view);



    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int position) {

        // bind the textview with data received

//        String title = data.get(i);
        User user = data.get(position);
        viewHolder.firstname.setText(user.getProductName());
        viewHolder.perprice.setText(user.getPerProductPrice());
        viewHolder.lastname.setText(user.getProductQuantity());
        viewHolder.price.setText(user.getTotalProductPrice());

//        mDatabase=FirebaseDatabase.getInstance();
//            mRef=mDatabase.getReference(" Users");
//
//        Map<String,Object> UpdatedValues = new HashMap<>();
//                    UpdatedValues.put("/Cart/-M_kMcFOSZG2YLiD8NZG/ProductQuantity",viewHolder.lastname);
////                    UpdatedValues.put("/Cart/-M_kMcFOSZG2YLiD8NZG/TotalProductPrice",price);
//                    mRef.updateChildren(UpdatedValues);

//        Locale locale=new Locale("en" ,"U8");
//        NumberFormat fmt=NumberFormat.getCurrencyInstance(locale);
//int total = (Integer.parseInt(data.get(position).TotalProductPrice + data.get(position).TotalProductPrice));
//        viewHolder.subtotal.setText(fmt.format(total));


        // similarly you can set new image for each card and descriptions
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        TextView firstname,perprice,lastname,price;
        TextView subtotal;
        Button add,sub,placeorder;
        ImageView cancel;

        FirebaseDatabase mDatabase;
        DatabaseReference mRef;
//        String price1;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
//            itemView.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
////                    Intent i = getIntent(v.getContext(), details.class);
////                    i.putExtra("title",data.get(getAdapterPosition()));
////                    v.getContext().startActivity(i);
//
//
//
//
//                    //        Intent i = getIntent();
////        String title = i.getStringExtra("title");
////        textTitle = findViewById(R.id.detailTitle);
////        textTitle.setText(title);
//                }
//            });



            mDatabase=FirebaseDatabase.getInstance();
            mRef=mDatabase.getReference(" Users");
            firstname = itemView.findViewById(R.id.soldItemName);
            perprice=itemView.findViewById(R.id.perorderprice);
            lastname = itemView.findViewById(R.id.orderNumber);
            price= itemView.findViewById(R.id.orderprice);
            subtotal=itemView.findViewById(R.id.subtotal);
          add=itemView.findViewById(R.id.btncartAdd);
            sub=itemView.findViewById(R.id.btncartSub);
            cancel=itemView.findViewById(R.id.cancel);
            placeorder=itemView.findViewById(R.id.Confirmorder);




//           String price1=price.getText().toString();
//            int price2=Integer.parseInt(price1);
//            price2+=price2;
//
//            subtotal.setText(""+price2);

            add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String lastname1 = lastname.getText().toString().trim();
                    int lastname2 = Integer.parseInt(lastname1);
                    Total = lastname2 + 1;
                    lastname.setText("" + Total);

                    String p = perprice.getText().toString().trim();
                    Double protein = Double.parseDouble(p);

                    String price1 = price.getText().toString().trim();
                    Double price2 = Double.parseDouble(price1);
                    price2 += protein;
                    price.setText("" + price2);




                }
            });

            sub.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (Total >= 1) {
                        String lastname1 = lastname.getText().toString().trim();
                        int lastname2 = Integer.parseInt(lastname1);
                        Total = lastname2 - 1;

                        lastname.setText("" + Total);

                        String p = perprice.getText().toString().trim();
                        Double protein = Double.parseDouble(p);

                        String price1 = price.getText().toString().trim();
                        Double price2 = Double.parseDouble(price1);
                        price2 -= protein;
                    price.setText("" + price2);
                    }
                }
            });

//
//            placeorder.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
////
//                    String lastname1 = lastname.getText().toString().trim();
//                    Map<String,Object> UpdatedValues = new HashMap<>();
//                    UpdatedValues.put("/Cart/ProductQuantity",lastname1);
//                    UpdatedValues.put("/Cart/TotalProductPrice",price);
//                    mRef.updateChildren(UpdatedValues);
//                    mRef.orderByChild("ProductQuantity").equalTo(lastname1).addListenerForSingleValueEvent(new ValueEventListener() {
//                        @Override
//                        public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//
//
//
//                        }
//
//                        @Override
//                        public void onCancelled(@NonNull DatabaseError error) {
//
//                        }
//                    });
//                }
//                });

//            Double totalammount=0.00 ;
//
//            String p = perprice.getText().toString().trim();
//            Double protein = Double.parseDouble(p);
//
//            String pricea = price.getText().toString().trim();
//            Double priceb = Double.parseDouble(pricea);
//            priceb *= protein;
//            price.setText("" + priceb);

//            totalammount = totalammount + priceb;
//            subtotal.setText("" +priceb);

        }

    }
}
