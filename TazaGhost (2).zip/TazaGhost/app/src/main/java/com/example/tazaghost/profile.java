package com.example.tazaghost;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class profile extends AppCompatActivity {

    EditText name,email,password,phoneno,address;
    Button update;


    FirebaseAuth mAuth;
    FirebaseDatabase mDatabase;
    DatabaseReference mRef;
    FirebaseAuth.AuthStateListener mAuthStateListener;
    private static final String TAG =  "MyTAG" ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        name=findViewById(R.id.etuName);
        email=findViewById(R.id.etuEmail);
        password=findViewById(R.id.etuPassword);
        phoneno=findViewById(R.id.etuPhone);
        address=findViewById(R.id.etuaddress);

        update=findViewById(R.id.btnupdate);

        mDatabase=FirebaseDatabase.getInstance();
        mRef=mDatabase.getReference("Users");

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String Iname = name.getText().toString();
                String Iphone = phoneno.getText().toString();
                String Iemail = email.getText().toString();
                String Ipassword = password.getText().toString();
                String Iaddress = address.getText().toString();


                Query query=mRef.orderByChild("Users");
                query.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {

                        for (DataSnapshot ds:snapshot.getChildren()){
                            ds.getRef().child("Address").setValue(Iaddress);
                            ds.getRef().child("Email").setValue(Iemail);
                            ds.getRef().child("Name").setValue(Iname);
                            ds.getRef().child("Password").setValue(Ipassword);
                            ds.getRef().child("Phone").setValue(Iphone);

                        }
                        Toast.makeText(profile.this,"Updated Successfully",Toast.LENGTH_SHORT).show();

                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


//Authentication
                //Validation check karain gy
                if (!ValidateEmailAddress() | !validatePassword()) {
                    //Email & password not valid
                    return;
                }
            }
        });


    }

    private boolean ValidateEmailAddress() {
        String Email=email.getText().toString().trim();

        if (Email.isEmpty())
        {
            email.setError("Email is Required.Cant be Empty");
            return false;
        }
        else if (!Patterns.EMAIL_ADDRESS.matcher(Email).matches())
        {
            email.setError("Invalid Email. Enter valid Email address");
            return false;
        }
        else {
            email.setError(null);
            return true;
        }
    }

    private boolean validatePassword() {
        String Password=password.getText().toString().trim();

        if (Password.isEmpty())
        {
            password.setError("Password is Required.Cant be Empty");
            return false;
        }
        else if (Password.length()<6)
        {
            password.setError("Password short Minimum 6 characters required");
            return false;
        }
        else {
            password.setError(null);
            return true;
        }
    }

}
