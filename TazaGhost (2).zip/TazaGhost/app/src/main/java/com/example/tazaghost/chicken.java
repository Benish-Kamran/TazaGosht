package com.example.tazaghost;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class chicken extends AppCompatActivity {


    Button wingorder,Wongtonorder,Drumstickorder;
    TextView wing,wingprice,Wongton,Wongtonprice,Drumstick,Drumstickprice;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chicken);


        wing=(TextView)findViewById(R.id.wing);
        wingprice=(TextView)findViewById(R.id.wingprice);
        wingorder=(Button)findViewById(R.id.btnOrderWing);


        Wongton=(TextView)findViewById(R.id.Wongton);
        Wongtonprice=(TextView)findViewById(R.id.WongtonPrice);
        Wongtonorder=(Button)findViewById(R.id.btnOrderWongton);

        Drumstick=(TextView)findViewById(R.id.DrumStick);
        Drumstickprice=(TextView)findViewById(R.id.DrumStickPrice);
        Drumstickorder=(Button)findViewById(R.id.btnOrderDrumStick);


        final TextView manchorian=(TextView)findViewById(R.id.Manchorian);
        final TextView manchorianprice=(TextView)findViewById(R.id.Manchorianprice);
        Button manchorianorder=(Button) findViewById(R.id.btnOrderManchorian);

        final TextView chowmein=(TextView)findViewById(R.id.Chowmein);
        final TextView chowmeinprice=(TextView)findViewById(R.id.ChowmeinPrice);
        Button chowmeinorder=(Button) findViewById(R.id.btnOrderChowmein);

        final TextView chilli=(TextView)findViewById(R.id.Chilli);
        final TextView chilliprice=(TextView)findViewById(R.id.ChilliPrice);
        Button chilliorder=(Button) findViewById(R.id.btnOrderChilli);

        final TextView Turkish=(TextView)findViewById(R.id.Turkish);
        final TextView Turkishprice=(TextView)findViewById(R.id.Turkishprice);
        Button Turkishorder=(Button) findViewById(R.id.btnOrderTurkish);

        final TextView Biryani=(TextView)findViewById(R.id.Biryani);
        final TextView Biryaniprice=(TextView)findViewById(R.id.BiryaniPrice);
        Button Biryaniorder=(Button) findViewById(R.id.btnOrderBiryani);

        final TextView Botitikka=(TextView)findViewById(R.id.Botitikka);
        final TextView Botitikkaprice=(TextView)findViewById(R.id.BotitikkaPrice);
        Button Botitikkaorder=(Button) findViewById(R.id.btnOrderBotitikka);

        final TextView Reshakabab=(TextView)findViewById(R.id.ReshaKabab);
        final TextView Reshakababprice=(TextView)findViewById(R.id.ReshaKababprice);
        Button Reshakababorder=(Button) findViewById(R.id.btnOrderReshaKabab);

        final TextView Stew=(TextView)findViewById(R.id.Stew);
        final TextView Stewprice=(TextView)findViewById(R.id.StewPrice);
        Button Steworder=(Button) findViewById(R.id.btnOrderStew);

        final TextView Karahi=(TextView)findViewById(R.id.Karahi);
        final TextView karahiprice=(TextView)findViewById(R.id.KarahiPrice);
        Button karahiorder=(Button) findViewById(R.id.btnOrderKarahi);



        wingorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=wing.getText().toString();
                String jalapenooprice=wingprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.bihariboti);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });

        Wongtonorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {




                String jalapenoo=Wongton.getText().toString();
                String jalapenooprice=Wongtonprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.biryanicut);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        Drumstickorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=Drumstick.getText().toString();
                String jalapenooprice=Drumstickprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.boneless);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        manchorianorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=manchorian.getText().toString();
                String jalapenooprice=manchorianprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.drumstick);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        chowmeinorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=chowmein.getText().toString();
                String jalapenooprice=chowmeinprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.golden);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        chilliorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=chilli.getText().toString();
                String jalapenooprice=chilliprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.handicut);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        Turkishorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=Turkish.getText().toString();
                String jalapenooprice=Turkishprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.karachicut);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        Biryaniorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=Biryani.getText().toString();
                String jalapenooprice=Biryaniprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.keema);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        Botitikkaorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=Botitikka.getText().toString();
                String jalapenooprice=Botitikkaprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.thighcut);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        Reshakababorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=Reshakabab.getText().toString();
                String jalapenooprice=Reshakababprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.tikka);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        Steworder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=Stew.getText().toString();
                String jalapenooprice=Stewprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.skin);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        karahiorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=Karahi.getText().toString();
                String jalapenooprice=karahiprice.getText().toString();

                Intent intent=new Intent(chicken.this,order.class);
                intent.putExtra("resId",R.drawable.chicken);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });

    }
}