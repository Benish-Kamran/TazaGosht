package com.example.tazaghost;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Mutton extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mutton);


        final TextView back=(TextView)findViewById(R.id.backchops);
        final TextView backprice=(TextView)findViewById(R.id.backchopsprice);
        Button backorder=(Button) findViewById(R.id.btnOrderbackchops);

        final TextView brain=(TextView)findViewById(R.id.mbrainmutton);
        final TextView brainprice=(TextView)findViewById(R.id.mbrainmuttonPrice);
        Button brainordermutton=(Button) findViewById(R.id.btnOrdermuttonbrain);

        final TextView front=(TextView)findViewById(R.id.mfront);
        final TextView frontprice=(TextView)findViewById(R.id.mfrontPrice);
        Button frontorder=(Button) findViewById(R.id.btnOrdermfront);


        final TextView kidney=(TextView)findViewById(R.id.kidney);
        final TextView kidneyprice=(TextView)findViewById(R.id.kidneyprice);
        Button kidneyorder=(Button) findViewById(R.id.btnOrderkidney);

        final TextView leg=(TextView)findViewById(R.id.leg);
        final TextView legprice=(TextView)findViewById(R.id.legPrice);
        Button legorder=(Button) findViewById(R.id.btnOrderleg);

        final TextView liver=(TextView)findViewById(R.id.mliver);
        final TextView liverprice=(TextView)findViewById(R.id.mliverPrice);
        Button liverorder=(Button) findViewById(R.id.btnOrdermliver);

        final TextView mince=(TextView)findViewById(R.id.mmince);
        final TextView minceprice=(TextView)findViewById(R.id.mmincePrice);
        Button minceorder=(Button) findViewById(R.id.btnOrdermmince);

        final TextView mix=(TextView)findViewById(R.id.mix);
        final TextView mixprice=(TextView)findViewById(R.id.mixPrice);
        Button mixorder=(Button) findViewById(R.id.btnOrdermix);

        final TextView paya=(TextView)findViewById(R.id.mpaya);
        final TextView payaprice=(TextView)findViewById(R.id.mpayaprice);
        Button payaorder=(Button) findViewById(R.id.btnOrdermpaya);

        final TextView shoulder=(TextView)findViewById(R.id.shoulder);
        final TextView shoulderprice=(TextView)findViewById(R.id.shoulderPrice);
        Button shoulderorder=(Button) findViewById(R.id.btnOrdershoulder);

        final TextView siri=(TextView)findViewById(R.id.msiri);
        final TextView siriprice=(TextView)findViewById(R.id.msiriPrice);
        Button siriorder=(Button) findViewById(R.id.btnOrdermsiri);






        backorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=back.getText().toString();
                String jalapenooprice=backprice.getText().toString();

                Intent intent=new Intent(Mutton.this,order.class);
                intent.putExtra("resId",R.drawable.mback);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });

        brainordermutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String jalapenoo=brain.getText().toString();
                String jalapenooprice=brainprice.getText().toString();

          Intent intent=new Intent(Mutton.this,order.class);
                intent.putExtra("resId",R.drawable.mbrain);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        frontorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=front.getText().toString();
                String jalapenooprice=frontprice.getText().toString();

                Intent intent=new Intent(Mutton.this,order.class);
                intent.putExtra("resId",R.drawable.mfront);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        kidneyorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=kidney.getText().toString();
                String jalapenooprice=kidneyprice.getText().toString();

              Intent intent=new Intent(Mutton.this,order.class);
                intent.putExtra("resId",R.drawable.mkidney);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        legorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=leg.getText().toString();
                String jalapenooprice=legprice.getText().toString();

               Intent intent=new Intent(Mutton.this,order.class);
                intent.putExtra("resId",R.drawable.mleg);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        liverorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=liver.getText().toString();
                String jalapenooprice=liverprice.getText().toString();

                Intent intent=new Intent(Mutton.this,order.class);
                intent.putExtra("resId",R.drawable.mliver);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        minceorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=mince.getText().toString();
                String jalapenooprice=minceprice.getText().toString();

                 Intent intent=new Intent(Mutton.this,order.class);
                intent.putExtra("resId",R.drawable.mmince);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        mixorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=mix.getText().toString();
                String jalapenooprice=mixprice.getText().toString();

                Intent intent=new Intent(Mutton.this,order.class);
                intent.putExtra("resId",R.drawable.mmix);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        payaorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=paya.getText().toString();
                String jalapenooprice=payaprice.getText().toString();

                Intent intent=new Intent(Mutton.this,order.class);
                intent.putExtra("resId",R.drawable.mpaya);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        shoulderorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=shoulder.getText().toString();
                String jalapenooprice=shoulderprice.getText().toString();

                Intent intent=new Intent(Mutton.this,order.class);
                intent.putExtra("resId",R.drawable.mshoulder);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        siriorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=siri.getText().toString();
                String jalapenooprice=siriprice.getText().toString();

             Intent intent=new Intent(Mutton.this,order.class);
                intent.putExtra("resId",R.drawable.msari);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });



    }
}
