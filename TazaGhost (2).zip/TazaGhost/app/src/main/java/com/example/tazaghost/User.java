package com.example.tazaghost;

public class User {

    String ProductName,PerProductPrice,ProductQuantity,TotalProductPrice;


    public User(String productName,String perProductPrice, String productQuantity, String totalProductPrice) {
        ProductName = productName;
        PerProductPrice = perProductPrice;
        ProductQuantity = productQuantity;
        TotalProductPrice = totalProductPrice;
    }

    public User(){

    }

    public String getPerProductPrice() {
        return PerProductPrice;
    }

    public void setPerProductPrice(String perProductPrice) {
        PerProductPrice = perProductPrice;
    }

    public String getProductName() {
        return ProductName;
    }

    public String getProductQuantity() {
        return ProductQuantity;
    }


    public String getTotalProductPrice() {
        return TotalProductPrice;
    }

    public void setProductName(String productName) {
        ProductName = productName;
    }

    public void setProductQuantity(String productQuantity) {
        ProductQuantity = productQuantity;
    }

    public void setTotalProductPrice(String totalProductPrice) {
        TotalProductPrice = totalProductPrice;
    }
}
