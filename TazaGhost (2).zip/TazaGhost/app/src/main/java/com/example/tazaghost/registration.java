package com.example.tazaghost;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

//import com.example.tazaghost.databinding.ActivityRegistrationBinding;

public class registration extends AppCompatActivity {
//    private registration binding;
    EditText name,email,password,phone,address;
    Button loginhere,signup;

FirebaseAuth mAuth;
    FirebaseDatabase mDatabase;
    DatabaseReference mRef;
    FirebaseAuth.AuthStateListener mAuthStateListener;
    private static final String TAG =  "MyTAG" ;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        name=(EditText) findViewById(R.id.etLastName);
       email =(EditText) findViewById(R.id.etREmail);
        password=(EditText) findViewById(R.id.etRPassword);
        phone=(EditText) findViewById(R.id.etPhone);
        address=(EditText) findViewById(R.id.etAdress);
        signup=(Button) findViewById(R.id.btnsignup);
        loginhere=(Button) findViewById(R.id.Registerhere);

        mAuth= FirebaseAuth.getInstance();
        mDatabase=FirebaseDatabase.getInstance();
        mRef=mDatabase.getReference(" Users");


        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String Iname = name.getText().toString();
                String Iemail = email.getText().toString();
                String Iphone = phone.getText().toString();
                String Iaddress = address.getText().toString();
                String Ipassword = password.getText().toString();
                String key = mRef.push().getKey();

                mRef.child(key).child("Name").setValue(Iname).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                        Toast.makeText(registration.this,"Data Inserted Succesfully",Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Log.d(TAG,"OnFailure:" + e.getMessage());

                    }
                });

                mRef.child(key).child("Email").setValue(Iemail).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                        Toast.makeText(registration.this,"Data Inserted Succesfully",Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Log.d(TAG,"OnFailure:" + e.getMessage());

                    }
                });

                mRef.child(key).child("Password").setValue(Ipassword).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

                        Toast.makeText(registration.this,"Data Inserted Succesfully",Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Log.d(TAG,"OnFailure:" + e.getMessage());

                    }
                });

                mRef.child(key).child("Phone").setValue(Iphone).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

//                        Toast.makeText(registration.this,"Data Inserted Succesfully",Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Log.d(TAG,"OnFailure:" + e.getMessage());

                    }
                });

                mRef.child(key).child("Address").setValue(Iaddress).addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {

//                        Toast.makeText(registration.this,"Data Inserted Succesfully",Toast.LENGTH_LONG).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {

                        Log.d(TAG,"OnFailure:" + e.getMessage());

                    }
                });


//Authentication
                        //Validation check karain gy
                        if (! ValidateEmailAddress() | ! validatePassword())
                        {
                            //Email & password not valid
                            return;
                        }

                        //Email and password valid Create user here
                        String Email = email.getText().toString().trim();
                        String Password = password.getText().toString().trim();

                        mAuth.createUserWithEmailAndPassword(Email,Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {

                                if (task.isSuccessful()) {
                                    Toast.makeText(registration.this, "User Created", Toast.LENGTH_LONG).show();

                                }

                            }
                        })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {

                                        if (e instanceof FirebaseAuthUserCollisionException)
                                        {
                                            Toast.makeText(registration.this, "Email already in Use", Toast.LENGTH_LONG).show();
//                                            textbox.setText(" Email already in Use");
                                        }


                                    }
                                });
//firebase Error Handling
                    }
                });
// Registration

                //Authentication



                //Push Id's Sy
//            String key = mRef.push().getKey();
//
//            mRef.child(key).child("Name").setValue(Iname);
//            mRef.child(key).child("Email").setValue(Iemail);
//            mRef.child(key).child("Password").setValue(Ipassword);
//            mRef.child(key).child("Address").setValue(Iaddress);

                //Push Id's Sy


        loginhere.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent intent=new Intent(registration.this,login.class);
                startActivity(intent);

            }
        });

    }

private boolean ValidateEmailAddress() {
        String Email=email.getText().toString().trim();

        if (Email.isEmpty())
        {
            email.setError("Email is Required.Cant be Empty");
        return false;
        }
        else if (!Patterns.EMAIL_ADDRESS.matcher(Email).matches())
        {
        email.setError("Invalid Email. Enter valid Email address");
        return false;
        }
        else {
        email.setError(null);
        return true;
        }
        }

private boolean validatePassword() {
        String Password=password.getText().toString().trim();

        if (Password.isEmpty())
        {
            password.setError("Password is Required.Cant be Empty");
        return false;
        }
        else if (Password.length()<6)
        {
            password.setError("Password short Minimum 6 characters required");
        return false;
        }
        else {
            password.setError(null);
        return true;
        }
        }

        }