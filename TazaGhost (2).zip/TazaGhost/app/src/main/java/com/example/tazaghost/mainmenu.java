package com.example.tazaghost;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;

public class mainmenu extends AppCompatActivity {

    NavigationView nav;
    ActionBarDrawerToggle toggle;

    int icons[]=
            {
                    R.drawable.boneless,
                    R.drawable.bbonelesszerofat,
                    R.drawable.mshoulder,
                    R.drawable.fwhitepomfret,


            };


    String[] name={"CHICKEN","BEEF","MUTTON","SEA FOOD"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mainmenu);
        androidx.appcompat.widget.Toolbar toolbar=(Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);




        nav=(NavigationView) findViewById(R.id.navmenu);
        DrawerLayout drawerLayout=(DrawerLayout)findViewById(R.id.drawer);

        toggle=new ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.open,R.string.close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        nav.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuitem) {

                switch (menuitem.getItemId())
                {
                    case R.id.menu_home:
                        Intent intent=new Intent(mainmenu.this,mainmenu.class);
                        startActivity(intent);
                        Toast.makeText(getApplicationContext(),"Welcome to Home",Toast.LENGTH_LONG).show();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.menu_profile:
                        Intent intent1=new Intent(mainmenu.this,profile.class);
                        startActivity(intent1);
                        Toast.makeText(getApplicationContext(),"Welcome to My Profile",Toast.LENGTH_LONG).show();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;

                    case R.id.menu_aboutus:
                        Intent intent2=new Intent(mainmenu.this,aboutus.class);
                        startActivity(intent2);
//                        Toast.makeText(getApplicationContext(),"Histo",Toast.LENGTH_LONG).show();
                        drawerLayout.closeDrawer(GravityCompat.START);
                        break;
                }

                return true;
            }
        });



        final GridView grid =(GridView) findViewById(R.id.grid);
        grid.setAdapter(new menuadapter(name,icons, this));
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {




                switch (position) {
                    case 0:
                        String a=name[position];
                        Intent intent=new Intent(mainmenu.this, chicken.class);
                        intent.putExtra("a",a);
                        startActivity(intent);
                        break;
                    case 1:
                        String b=name[position];
                        Intent intent1=new Intent(mainmenu.this, beef.class);
                        intent1.putExtra("b",b);
                        startActivity(intent1);
                        break;

                    case 2:
                        String c=name[position];
                        Intent intent2=new Intent(mainmenu.this, Mutton.class);
                        intent2.putExtra("c",c);
                        startActivity(intent2);
                        break;

                    case 3:
                        String d=name[position];
                        Intent intent3=new Intent(mainmenu.this, fish.class);
                        intent3.putExtra("d",d);
                        startActivity(intent3);
                        break;


                }

            }
        });



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {


        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu,menu);
        return true;


    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        int id=item.getItemId();
        if (id==R.id.menu_cart){
            Intent intent=new Intent(mainmenu.this,addtocart.class);
            startActivity(intent);
        }
        return super.onOptionsItemSelected(item);
    }
}