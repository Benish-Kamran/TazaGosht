package com.example.tazaghost;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class addtocart extends AppCompatActivity {

    RecyclerView recyclerView;
    myadapter adapter;
//    ArrayList<User> items;
List<User> data;


    int resId;

    FirebaseDatabase mDatabase;
    DatabaseReference mRef;
    TextView placeorder,orderprice,subtotal;

//FirebaseAuth mAuth;
//FirebaseAuth.AuthStateListener mAuthListener;
//String userID;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addtocart);



//        TextView subtotal=findViewById(R.id.subtotal);

//
//        items = new ArrayList<>();
//
//        Bundle bundle = getIntent().getExtras();
//        if (bundle != null) {
//            resId = bundle.getInt("resId");
////            imagerecieve.setImageResource(resId);
//        }
//
//        int icons[] =
//                {
//                        resId,resId
//
//
//                };

//        Intent intent = getIntent();
//        String jalapeno = intent.getStringExtra("title");
//        String jalapenoo = intent.getStringExtra("titlee");
//        String jalapenooo = intent.getStringExtra("titleee");
//
//
//        String[] name = {jalapeno, jalapeno};
//        String[] quantity = {jalapenoo,jalapenoo};
//        String[] price = {jalapenooo,jalapenooo};

//items.add(jalapeno);
//
//        items.add("Second CardView Item");
//        items.add("Third CardView Item");
//        items.add("Fourth CardView Item");
//        items.add("Fifth CardView Item");
//        items.add("Sixth CardView Item");
//
//
//        mAuth = FirebaseAuth.getInstance();
        mDatabase=FirebaseDatabase.getInstance();
        mRef=mDatabase.getReference(" Users");
//        FirebaseUser user=mAuth.getCurrentUser();
//        userID=user.getUid();

       placeorder=findViewById(R.id.Confirmorder);
       orderprice=findViewById(R.id.orderprice);
        subtotal=findViewById(R.id.subtotal);
       TextView lastname = findViewById(R.id.orderNumber);
        TextView price= findViewById(R.id.orderprice);

        recyclerView = findViewById(R.id.recyclerView);

        data = new ArrayList<>();
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new myadapter(this,data);
        new ItemTouchHelper(simpleCallback).attachToRecyclerView(recyclerView);
        recyclerView.setAdapter(adapter);




//        mRef.child("-M_jeoaE1U1J_6G0sO9c").child("TotalProductPrice").addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//                String data= snapshot.getValue(String.class);
//                subtotal.setText(data);
//
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//
//            }
//        });

mRef.child("Cart").addValueEventListener(new ValueEventListener() {
    @Override
    public void onDataChange(@NonNull DataSnapshot snapshot) {

        for (DataSnapshot dataSnapshot : snapshot.getChildren()){

            User user=dataSnapshot.getValue(User.class);
            data.add(user);


//User user= new User();
//user.setProductName(dataSnapshot.child(userID).getValue(User.class).getProductName());
//user.setPerProductPrice(dataSnapshot.child(userID).getValue(User.class).getPerProductPrice());
//user.setProductQuantity(dataSnapshot.child(userID).getValue(User.class).getProductQuantity());
//user.setTotalProductPrice(dataSnapshot.child(userID).getValue(User.class).getTotalProductPrice());


//ArrayList<String> array=new ArrayList<>();
//array.add(user.getProductName());
//array.add(user.getPerProductPrice());
//array.add(user.getProductQuantity());
//array.add(user.getTotalProductPrice());
//
//adapter = new myadapter(this, android.R.layout.simple_list_item_1,array);
//recyclerView.setAdapter(adapter);


        }
        adapter.notifyDataSetChanged();



    }

    @Override
    public void onCancelled(@NonNull DatabaseError error) {

    }
});

//subtotal.setText(""+orderprice);



        placeorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                String lastname1 = lastname.getText().toString().trim();
//                    Map<String,Object> UpdatedValues = new HashMap<>();
//                    UpdatedValues.put("/Cart/-M_kMcFOSZG2YLiD8NZG/ProductQuantity",lastname);
//                    UpdatedValues.put("/Cart/-M_kMcFOSZG2YLiD8NZG/TotalProductPrice",price);
//                    mRef.updateChildren(UpdatedValues);
//                String a =lastname.getText().toString();
//                mRef.orderByChild("ProductQuantity").equalTo(a);
//                var pushedRef = firebase.database().ref('/customers').push({ email: email });
//                console.log(pushedRef.key);

//                mRef.child("Cart").addValueEventListener(new ValueEventListener() {
//                    @Override
//                    public void onDataChange(@NonNull DataSnapshot snapshot) {
//
//                        for (DataSnapshot dataSnapshot : snapshot.getChildren()){
//
//                            User user=dataSnapshot.getValue(User.class);
//
////                            Map<String,Object> UpdatedValues = new HashMap<>();
////                    UpdatedValues.put("/Cart/-M_kMcFOSZG2YLiD8NZG/ProductQuantity",lastname);
////                    UpdatedValues.put("/Cart/-M_kMcFOSZG2YLiD8NZG/TotalProductPrice",price);
//                    mRef.updateChildren((Map<String, Object>) user);
//
//                            data.add(user);
//
//
//
//
//                        }
//                        adapter.notifyDataSetChanged();
//
//
//
//                    }
//
//                    @Override
//                    public void onCancelled(@NonNull DatabaseError error) {
//
//                    }
//                });

                    Toast.makeText(addtocart.this,"Thankyou Your Order Has Been Published", Toast.LENGTH_LONG).show();

            }
        });

//        final GridView grid =(GridView) findViewById(R.id.gridaddtocart);
//        grid.setAdapter(this,items);

//       recyclerView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//


//
//                switch (position) {
//                    case 0:
//                        String a=name[position];
//                        Intent intent=new Intent(mainmenu.this, chicken.class);
//                        intent.putExtra("a",a);
//                        startActivity(intent);
//                        break;
//                    case 1:
//                        String b=name[position];
//                        Intent intent1=new Intent(mainmenu.this, beef.class);
//                        intent1.putExtra("b",b);
//                        startActivity(intent1);
//                        break;
//
//                    case 2:
//                        String c=name[position];
//                        Intent intent2=new Intent(mainmenu.this, Mutton.class);
//                        intent2.putExtra("c",c);
//                        startActivity(intent2);
//                        break;
//
//                    case 3:
//                        String d=name[position];
//                        Intent intent3=new Intent(mainmenu.this, fish.class);
//                        intent3.putExtra("d",d);
//                        startActivity(intent3);
//                        break;


//                }
//
//            }
//        });



    }
    ItemTouchHelper.SimpleCallback simpleCallback=new ItemTouchHelper.SimpleCallback(0,ItemTouchHelper.RIGHT | ItemTouchHelper.LEFT) {
        @Override
        public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder, @NonNull RecyclerView.ViewHolder target) {
            return false;
        }

        @Override
        public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
data.remove(viewHolder.getAdapterPosition());

            String key = mRef.child("Cart").push().getKey();
Task<Void> task=mRef.child("Cart").child(key).removeValue();


            adapter.notifyDataSetChanged();

        }
    };


}

