package com.example.tazaghost;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class fish extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fish);



        final TextView kund=(TextView)findViewById(R.id.blackkund);
        final TextView kundprice=(TextView)findViewById(R.id.blackkundprice);
        Button kundorder=(Button) findViewById(R.id.btnOrderblackkund);

        final TextView pomfret=(TextView)findViewById(R.id.blackpomfret);
        final TextView pomfretprice=(TextView)findViewById(R.id.blackpomfretPrice);
        Button pomfretorder=(Button) findViewById(R.id.btnOrderblackpomfret);


        final TextView bream=(TextView)findViewById(R.id.bream);
        final TextView breamprice=(TextView)findViewById(R.id.breamPrice);
        Button breamorder=(Button) findViewById(R.id.btnOrdermbream);



        final TextView grunter=(TextView)findViewById(R.id.grunter);
        final TextView grunterprice=(TextView)findViewById(R.id.grunterprice);
        Button grunterorder=(Button) findViewById(R.id.btnOrdergrunter);

        final TextView king=(TextView)findViewById(R.id.king);
        final TextView kingprice=(TextView)findViewById(R.id.kingPrice);
        Button kingorder=(Button) findViewById(R.id.btnOrderking);

        final TextView mushka=(TextView)findViewById(R.id.mushka);
        final TextView mushkaprice=(TextView)findViewById(R.id.mushkaPrice);
        Button mushkaorder=(Button) findViewById(R.id.btnOrdermushkafillet);


        final TextView mushkafillet=(TextView)findViewById(R.id.mushka);
        final TextView mushkafilletprice=(TextView)findViewById(R.id.mushkaPrice);
        Button mushkafilletorder=(Button) findViewById(R.id.btnOrdermushkafillet);

        final TextView prawn=(TextView)findViewById(R.id.prawn);
        final TextView prawnprice=(TextView)findViewById(R.id.prawnPrice);
        Button prawnorder=(Button) findViewById(R.id.btnOrderprawn);

        final TextView prawnmore=(TextView)findViewById(R.id.prawnmore);
        final TextView prawnmoreprice=(TextView)findViewById(R.id.prawnPrice);
        Button prawnmoreorder=(Button) findViewById(R.id.btnOrderprawnmore);

        final TextView queen=(TextView)findViewById(R.id.queen);
        final TextView queenprice=(TextView)findViewById(R.id.queenPrice);
        Button queenorder=(Button) findViewById(R.id.btnOrderqueen);

        final TextView queenfillet=(TextView)findViewById(R.id.queenfillet);
        final TextView queenfilletprice=(TextView)findViewById(R.id.queenfilletPrice);
        Button queenfilletorder=(Button) findViewById(R.id.btnOrdermqueenfillet);

        final TextView red=(TextView)findViewById(R.id.red);
        final TextView redprice=(TextView)findViewById(R.id.redprice);
        Button redorder=(Button) findViewById(R.id.btnOrderred);

        final TextView whitekund=(TextView)findViewById(R.id.whitekund);
        final TextView whitekundprice=(TextView)findViewById(R.id.whitekundPrice);
        Button whitekundrorder=(Button) findViewById(R.id.btnOrderwhitekund);

        final TextView whitepomfret=(TextView)findViewById(R.id.whitepomfret);
        final TextView whitepomfretprice=(TextView)findViewById(R.id.whitepomfretPrice);
        Button whitepomfretorder=(Button) findViewById(R.id.btnOrderwhitepomfret);



        kundorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=kund.getText().toString();
                String jalapenooprice=kundprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.bblack);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });




        pomfretorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=pomfret.getText().toString();
                String jalapenooprice=pomfretprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.bpromfat);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        breamorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=bream.getText().toString();
                String jalapenooprice=breamprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.bbream);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });




        grunterorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=grunter.getText().toString();
                String jalapenooprice=grunterprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.fgrunter);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });

        kingorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String jalapenoo=king.getText().toString();
                String jalapenooprice=kingprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.fking);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        mushkaorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=mushka.getText().toString();
                String jalapenooprice=mushkaprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.fmushka);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        mushkafilletorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=mushkafillet.getText().toString();
                String jalapenooprice=mushkafilletprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.fmushkafillet);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        prawnorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=prawn.getText().toString();
                String jalapenooprice=prawnprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.fprawn);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        prawnmoreorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=prawnmore.getText().toString();
                String jalapenooprice=prawnmoreprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.fprawnmore);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        queen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=queen.getText().toString();
                String jalapenooprice=queenfilletprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.fqueen);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        queenfillet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=queenfillet.getText().toString();
                String jalapenooprice=queenfilletprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.fqueenfillet);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        redorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=red.getText().toString();
                String jalapenooprice=redprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.fred);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        whitekundrorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=whitekund.getText().toString();
                String jalapenooprice=whitekundprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.fwhitekund);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });


        whitepomfretorder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String jalapenoo=whitepomfret.getText().toString();
                String jalapenooprice=whitepomfretprice.getText().toString();

                Intent intent=new Intent(fish.this,order.class);
                intent.putExtra("resId",R.drawable.fwhitepomfret);
                intent.putExtra("jalapenosend",jalapenoo);
                intent.putExtra("jalapenopricesend",jalapenooprice);
                startActivity(intent);

            }
        });

    }
}
